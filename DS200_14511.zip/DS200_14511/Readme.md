The plots in the attatched file are drawn from the data which i got from the link given below.
Link : https://data.gov.in/resources/district-wise-number-poultry-farms-and-poultry-birds-farms-2007-andhra-pradesh
Last accessed : 08th jan 2018 at 03:50pm.

Using the data 5 files named data.csv, data1.csv, data2.csv, data3.csv and data4.csv are created.

data1.csv and data2.csv are used for scatter plot.
data3.csv is used for box plot.
data4.csv is used for bar plot.


Using the scatter plot we can see that the rural areas in the district produce more number of poultry birds than any urban region in any district.

From the box plot we can get that there are rural areas of some districts which produce much higher than the median of the data and they play a major role in the total number of poultry birds in the state.

Using the bar plot we can get that the EastGodavari District has the highest number of poultry birds and the Hyderabad district has the lowest number of poultry birds in total(that is in both rural and urban areas mixed).